for fname in $1*
do
  grep $2 $fname > /dev/null
  if test $? -eq 0; then
     echo Datoteka $fname sadrzi $2
  else
     echo Datoteka $fname ne sadrzi $2
  fi
done
 

